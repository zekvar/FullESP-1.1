FULL ESP 1.1 — Dark Edition (training demo)

Это исходный проект Android Studio для автономной демонстрации ESP-подобной
визуализации на собственной тестовой сцене. Он НЕ подключается к Standoff 2,
не читает память игры и не показывает реальных игроков.

Как собрать APK:
1. Установи Android Studio.
2. Открой папку FullESPTrainingDemo как проект.
3. Дождись синхронизации Gradle.
4. Выбери Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK появится в app/build/outputs/apk/debug/app-debug.apk.

Требуется Android SDK 35 и JDK, поддерживаемый установленной версией Android Studio.
