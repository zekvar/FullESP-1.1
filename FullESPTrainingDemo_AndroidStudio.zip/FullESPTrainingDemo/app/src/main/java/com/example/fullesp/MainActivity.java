package com.example.fullesp;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.Context;

public class MainActivity extends Activity {
    private DemoView demo;
    private final String[] labels = {"Box ESP", "Name ESP", "Health ESP", "Distance ESP", "Skeleton ESP", "Enemy ESP"};
    private final boolean[] enabled = {true, true, true, true, false, true};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(9,10,12));
        getWindow().setNavigationBarColor(Color.rgb(9,10,12));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(14), dp(16), dp(12));
        page.setBackgroundColor(Color.rgb(11,12,14));

        TextView title = text("FULL ESP 1.1", 23, true);
        page.addView(title);
        TextView sub = text("DARK EDITION  •  TRAINING DEMO", 11, false);
        sub.setTextColor(Color.rgb(145,151,160));
        page.addView(sub);

        TextView note = text("Автономная демо-сцена — не подключается к Standoff 2", 12, false);
        note.setTextColor(Color.rgb(190,196,204));
        note.setPadding(0, dp(12), 0, dp(8));
        page.addView(note);

        demo = new DemoView(this);
        LinearLayout.LayoutParams sceneParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
        sceneParams.topMargin = dp(8);
        sceneParams.bottomMargin = dp(10);
        page.addView(demo, sceneParams);

        TextView controls = text("ESP CONTROL", 13, true);
        controls.setTextColor(Color.rgb(195,201,209));
        page.addView(controls);

        for (int i=0; i<labels.length; i++) {
            final int index = i;
            Switch sw = new Switch(this);
            sw.setText(labels[i]);
            sw.setTextColor(Color.WHITE);
            sw.setTextSize(14);
            sw.setPadding(dp(2), dp(3), dp(2), dp(3));
            sw.setChecked(enabled[i]);
            sw.setOnCheckedChangeListener((button, checked) -> {
                enabled[index] = checked;
                demo.invalidate();
            });
            page.addView(sw);
        }

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button all = new Button(this); all.setText("ВКЛЮЧИТЬ ВСЁ");
        Button off = new Button(this); off.setText("ВЫКЛЮЧИТЬ");
        buttons.addView(all, new LinearLayout.LayoutParams(0, dp(48), 1));
        buttons.addView(off, new LinearLayout.LayoutParams(0, dp(48), 1));
        all.setOnClickListener(v -> { for(int i=0;i<enabled.length;i++) enabled[i]=true; recreate(); });
        off.setOnClickListener(v -> { for(int i=0;i<enabled.length;i++) enabled[i]=false; recreate(); });
        page.addView(buttons);

        setContentView(page);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(Color.WHITE);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    class DemoView extends View {
        Paint p = new Paint(3);
        DemoView(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        void line(Canvas c, float x1,float y1,float x2,float y2,int color,float w) {
            p.setColor(color); p.setStrokeWidth(w); p.setStyle(Paint.Style.STROKE); c.drawLine(x1,y1,x2,y2,p);
        }
        void label(Canvas c, String s, float x,float y) {
            p.setStyle(Paint.Style.FILL); p.setTextSize(27); p.setTypeface(Typeface.DEFAULT_BOLD);
            p.setColor(Color.BLACK); c.drawText(s,x+2,y+2,p); p.setColor(Color.rgb(225,230,236)); c.drawText(s,x,y,p);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            p.setStyle(Paint.Style.FILL); p.setShader(new LinearGradient(0,0,0,h,Color.rgb(39,43,49),Color.rgb(17,19,23),Shader.TileMode.CLAMP));
            c.drawRoundRect(0,0,w,h,dp(14),dp(14),p); p.setShader(null);
            p.setColor(Color.rgb(57,63,71)); c.drawRect(0,h*.56f,w,h,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1);
            for(int i=1;i<6;i++) c.drawLine(0,h*.56f+i*dp(32),w,h*.56f+i*dp(32),p);
            bot(c,w*.36f,h*.36f,"BOT_01","12 м",.95f);
            bot(c,w*.72f,h*.54f,"BOT_02","24 м",.72f);
            p.setStyle(Paint.Style.FILL); p.setTextSize(dp(10)); p.setColor(Color.rgb(177,184,193));
            c.drawText("TRAINING RANGE",dp(12),h-dp(12),p);
        }
        void bot(Canvas c,float cx,float cy,String name,String dist,float scale) {
            c.save(); c.translate(cx,cy); c.scale(scale,scale);
            int white=Color.rgb(218,224,231), gray=Color.rgb(130,139,150);
            p.setStyle(Paint.Style.FILL); p.setColor(gray);
            c.drawCircle(0,0,dp(10),p); c.drawRoundRect(-dp(16),dp(12),dp(16),dp(58),dp(6),dp(6),p);
            c.drawRect(-dp(13),dp(58),-dp(5),dp(91),p); c.drawRect(dp(5),dp(58),dp(13),dp(91),p);
            if(enabled[0]) { p.setColor(white); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(dp(2)); c.drawRect(-dp(25),-dp(14),dp(25),dp(98),p); }
            if(enabled[1]) label(c,name,-dp(28),-dp(24));
            if(enabled[2]) { p.setStyle(Paint.Style.FILL); p.setColor(Color.DKGRAY); c.drawRect(-dp(34),-dp(10),-dp(29),dp(88),p); p.setColor(white); c.drawRect(-dp(34),-dp(10),-dp(29),dp(55),p); }
            if(enabled[3]) label(c,dist,-dp(14),dp(119));
            if(enabled[4]) {
                line(c,0,dp(12),0,dp(57),white,dp(2));
                line(c,-dp(19),dp(28),dp(19),dp(28),white,dp(2));
                line(c,0,dp(57),-dp(12),dp(88),white,dp(2));
                line(c,0,dp(57),dp(12),dp(88),white,dp(2));
            }
            if(enabled[5]) { p.setStyle(Paint.Style.STROKE); p.setColor(Color.rgb(185,193,202)); p.setStrokeWidth(dp(1)); c.drawCircle(0,0,dp(31),p); }
            c.restore();
        }
    }
}
